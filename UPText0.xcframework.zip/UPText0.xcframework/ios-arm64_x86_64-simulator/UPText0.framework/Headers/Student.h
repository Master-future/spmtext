//
//  Student.h
//  UPText0
//
//  Created by future on 2024/8/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Student : NSObject

@end

NS_ASSUME_NONNULL_END
