//
//  UPText0.h
//  UPText0
//
//  Created by future on 2024/8/22.
//

#import <Foundation/Foundation.h>
#import <UPText0/Person.h>
#import <UPText0/Student.h>

//! Project version number for UPText0.
FOUNDATION_EXPORT double UPText0VersionNumber;

//! Project version string for UPText0.
FOUNDATION_EXPORT const unsigned char UPText0VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UPText0/PublicHeader.h>


